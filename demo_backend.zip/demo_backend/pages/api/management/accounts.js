import pool from '../../../lib/db';

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ success: false });

  const { tab, search } = req.query;
  const like = search ? `%${search}%` : '%';

  try {
    let data = [];

    if (!tab || tab === 'users') {
      const [rows] = await pool.execute(
        `SELECT id, name, phone, role, status FROM users WHERE name LIKE ? OR phone LIKE ?`,
        [like, like]
      );
      data = rows.map(r => ({ ...r, type: 'user' }));
    }

    if (tab === 'lab_partners') {
      const [rows] = await pool.execute(
        `SELECT id, name, phone, lab_type, status FROM lab_partners WHERE name LIKE ? OR phone LIKE ?`,
        [like, like]
      );
      data = rows.map(r => ({ ...r, type: 'lab_partner' }));
    }

    return res.status(200).json({ success: true, total: data.length, data });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
}

import pool from '../../../lib/db';

export default async function handler(req, res) {
  if (req.method !== 'PATCH') return res.status(405).json({ success: false });

  const { id, type, action } = req.body;
  const newStatus = action === 'suspend' ? 'suspended' : 'active';
  const table = type === 'lab_partner' ? 'lab_partners' : 'users';

  try {
    await pool.execute(`UPDATE ${table} SET status = ? WHERE id = ?`, [newStatus, id]);
    return res.status(200).json({ success: true, message: `Account ${newStatus}` });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
}

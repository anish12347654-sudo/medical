import pool from '../../../lib/db';

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ success: false });

  const { tab } = req.query;

  let where = '';
  if (tab === 'active') where = `WHERE status IN ('in_progress', 'processing')`;
  else if (tab === 'completed') where = `WHERE status = 'delivered'`;

  try {
    const [orders] = await pool.execute(
      `SELECT id, order_id, user_name, message, status, created_at FROM orders ${where} ORDER BY created_at DESC`
    );

    const statusLabel = {
      in_progress: 'Verifying Prescription',
      processing: 'Processing',
      delivered: 'Delivered',
      cancelled: 'Cancelled',
    };

    return res.status(200).json({
      success: true,
      orders: orders.map(o => ({
        ...o,
        status_label: statusLabel[o.status] || o.status,
        created_formatted: new Date(o.created_at).toLocaleDateString('en-IN', {
          day: '2-digit', month: 'short', year: 'numeric'
        }),
      })),
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
}

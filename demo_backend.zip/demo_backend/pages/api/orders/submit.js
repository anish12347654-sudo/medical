import pool from '../../../lib/db';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ success: false });

  const { message, prescription_url, image_url } = req.body;

  const orderId = `ML-${Math.floor(10000 + Math.random() * 90000)}`;

  try {
    const [result] = await pool.execute(
      `INSERT INTO orders (order_id, user_name, message, prescription_url, image_url, status, created_at)
       VALUES (?, 'Demo User', ?, ?, ?, 'in_progress', NOW())`,
      [orderId, message || null, prescription_url || null, image_url || null]
    );

    return res.status(201).json({
      success: true,
      order: { id: result.insertId, order_id: orderId, status: 'in_progress' },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
}

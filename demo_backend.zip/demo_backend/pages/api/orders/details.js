import pool from '../../../lib/db';

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ success: false });

  const { order_id } = req.query;
  if (!order_id) return res.status(400).json({ success: false, message: 'order_id required' });

  try {
    const [rows] = await pool.execute(
      `SELECT id, order_id, user_name, message, status, created_at FROM orders WHERE order_id = ?`,
      [order_id]
    );

    if (!rows.length) return res.status(404).json({ success: false, message: 'Order not found' });

    const order = rows[0];

    const steps = ['in_progress', 'processing', 'delivered'];
    const labels = { in_progress: 'Order Received', processing: 'Processing', delivered: 'Delivered' };
    const currentIndex = steps.indexOf(order.status);

    const timeline = steps.map((step, i) => ({
      step,
      label: labels[step],
      completed: i <= currentIndex,
      active: step === order.status,
    }));

    return res.status(200).json({ success: true, order: { ...order, timeline } });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
}

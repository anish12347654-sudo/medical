# Medical App — Demo Backend

Simple Next.js + MySQL backend, client demo ke liye.
Koi auth nahi, koi JWT nahi — seedha kaam karta hai.

---

## Setup (2 steps)

**Step 1 — DB banao:**
```bash
mysql -u root -p < schema.sql
```

**Step 2 — Run karo:**
```bash
npm install
cp .env.example .env.local   # DB password bharo
npm run dev
# http://localhost:3001 pe chalega
```

---

## APIs

| Method | URL | Kaam |
|--------|-----|------|
| POST | /api/orders/submit | Order submit |
| GET | /api/orders/my-orders?tab=active | Orders list |
| GET | /api/orders/details?order_id=ML-89231 | Order detail + timeline |
| GET | /api/management/accounts?tab=users | Users/Labs list |
| PATCH | /api/management/update-status | Suspend/Reactivate |

---

## Flutter mein connect karna

```dart
const baseUrl = 'http://10.0.2.2:3001/api'; // Android emulator ke liye
// Real device pe: 'http://192.168.X.X:3001/api'

// Orders list
final res = await http.get(Uri.parse('$baseUrl/orders/my-orders?tab=active'));

// Order submit
final res = await http.post(
  Uri.parse('$baseUrl/orders/submit'),
  headers: {'Content-Type': 'application/json'},
  body: jsonEncode({'message': 'Paracetamol 500mg'}),
);
```

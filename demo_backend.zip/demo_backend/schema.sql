CREATE DATABASE IF NOT EXISTS medical_demo CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE medical_demo;

-- USERS
CREATE TABLE IF NOT EXISTS users (
  id       INT AUTO_INCREMENT PRIMARY KEY,
  name     VARCHAR(100),
  phone    VARCHAR(15) UNIQUE,
  role     VARCHAR(30) DEFAULT 'PHARMACY STAFF',
  status   ENUM('active','suspended') DEFAULT 'active'
);

INSERT IGNORE INTO users (name, phone, role, status) VALUES
('Dr. Sarah Jenkins', '9999999999', 'SUPER ADMIN',     'active'),
('Marcus Thorne',     '9888888888', 'PHARMACY STAFF',  'suspended'),
('Ravi Sharma',       '9777777777', 'PHARMACY STAFF',  'active');

-- LAB PARTNERS
CREATE TABLE IF NOT EXISTS lab_partners (
  id       INT AUTO_INCREMENT PRIMARY KEY,
  name     VARCHAR(150),
  phone    VARCHAR(15) UNIQUE,
  lab_type VARCHAR(50) DEFAULT 'STANDARD LAB',
  status   ENUM('active','suspended') DEFAULT 'active'
);

INSERT IGNORE INTO lab_partners (name, phone, lab_type, status) VALUES
('Apex Diagnostics', '9000000001', 'PREMIUM LAB',  'active'),
('City Path Labs',   '9000000002', 'STANDARD LAB', 'active');

-- ORDERS
CREATE TABLE IF NOT EXISTS orders (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  order_id         VARCHAR(20) UNIQUE,
  user_name        VARCHAR(100) DEFAULT 'Demo User',
  message          TEXT,
  prescription_url VARCHAR(500),
  image_url        VARCHAR(500),
  status           ENUM('in_progress','processing','delivered','cancelled') DEFAULT 'in_progress',
  created_at       DATETIME
);

INSERT IGNORE INTO orders (order_id, user_name, message, status, created_at) VALUES
('ML-89231', 'Rahul Mehta',  'Full Body Checkup',      'processing',  '2024-10-24 10:00:00'),
('PH-44102', 'Anita Singh',  'Prescription Medicines', 'in_progress', '2024-10-22 14:30:00'),
('DL-55301', 'Vikram Nair',  'Vitamin supplements',    'delivered',   '2024-10-17 09:00:00');
